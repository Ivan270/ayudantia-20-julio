<template>
  <h1>Restricted</h1>
</template>

<script>
export default {
  name: 'RestrictedView',
  // props: {},
  data: function(){
    return {}
  },
  // computed: {},
  //methods: {},
  // watch: {},
  // components: {},
  // mixins: [],
  // filters: {},
  // -- Lifecycle Methods
  // -- End Lifecycle Methods
}
</script>

<style scoped>
  
</style>